@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (py -3 verificar_integridade.py) else (python verificar_integridade.py)
pause
