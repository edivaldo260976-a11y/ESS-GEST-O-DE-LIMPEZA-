"""Importador conservador: preserva todos os valores originais do localStorage."""
import argparse, hashlib, json, sqlite3, datetime, pathlib

def importar(origem, destino):
    origem=pathlib.Path(origem); destino=pathlib.Path(destino)
    bruto=origem.read_bytes(); doc=json.loads(bruto.decode('utf-8-sig'))
    if not isinstance(doc.get('localStorage'),dict): raise ValueError('Backup sem localStorage válido')
    if destino.exists(): raise FileExistsError('Banco já existe; não será sobrescrito: '+str(destino))
    destino.parent.mkdir(parents=True,exist_ok=True)
    conn=sqlite3.connect(str(destino)); conn.execute('PRAGMA journal_mode=WAL'); conn.execute('PRAGMA foreign_keys=ON')
    try:
        with conn:
            conn.executescript('''CREATE TABLE backup_info (id INTEGER PRIMARY KEY CHECK(id=1), sistema TEXT, versao TEXT, formato TEXT, criado_em TEXT, total_clientes_declarado INTEGER, sha256_original TEXT NOT NULL, importado_em TEXT NOT NULL);
CREATE TABLE armazenamento_original (chave TEXT PRIMARY KEY, valor TEXT NOT NULL, json_valido INTEGER NOT NULL);
CREATE TABLE clientes_snapshot (chave_origem TEXT PRIMARY KEY REFERENCES armazenamento_original(chave), nome_codificado TEXT NOT NULL, locais_json TEXT NOT NULL, funcionarios_json TEXT NOT NULL, planos_json TEXT NOT NULL, programacao_json TEXT NOT NULL, execucoes_json TEXT NOT NULL, programacao_diaria_json TEXT NOT NULL, frequencia_rh_json TEXT NOT NULL);
CREATE TABLE auditoria_importacao (id INTEGER PRIMARY KEY AUTOINCREMENT, evento TEXT NOT NULL, detalhe TEXT, instante TEXT NOT NULL);''')
            conn.execute('INSERT INTO backup_info VALUES (1,?,?,?,?,?,?,?)',(doc.get('sistema'),doc.get('versao'),doc.get('formato'),doc.get('criadoEm'),doc.get('totalClientes'),hashlib.sha256(bruto).hexdigest(),datetime.datetime.now(datetime.timezone.utc).isoformat()))
            for k,v in doc['localStorage'].items():
                if not isinstance(v,str): raise ValueError('Valor de localStorage não textual: '+k)
                try: parsed=json.loads(v); valid=1
                except json.JSONDecodeError: parsed=None;valid=0
                conn.execute('INSERT INTO armazenamento_original VALUES (?,?,?)',(k,v,valid))
                if k.startswith('gl_cliente_v22_'):
                    if not isinstance(parsed,dict): raise ValueError('Cliente inválido: '+k)
                    fields=['locais','funcionarios','planosIntegrados','programacaoIntegrada','execucoesIntegradas','programacaoDiariaIntegrada','frequenciaRH']
                    conn.execute('INSERT INTO clientes_snapshot VALUES (?,?,?,?,?,?,?,?,?)',(k,k[len('gl_cliente_v22_'):],*(json.dumps(parsed.get(f),ensure_ascii=False,separators=(',',':')) for f in fields)))
            conn.execute('INSERT INTO auditoria_importacao(evento,detalhe,instante) VALUES (?,?,?)',('IMPORTACAO_INICIAL','Cópia conservadora, sem alterações nos dados originais',datetime.datetime.now(datetime.timezone.utc).isoformat()))
        check=dict(conn.execute('SELECT chave,valor FROM armazenamento_original'))
        assert check==doc['localStorage'],'Divergência no teste de ida e volta'
        assert conn.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
        print('IMPORTAÇÃO VALIDADA | chaves:',len(check),'| clientes snapshot:',conn.execute('SELECT count(*) FROM clientes_snapshot').fetchone()[0]);print('SHA256 original:',hashlib.sha256(bruto).hexdigest())
    except Exception:
        conn.close()
        for suffix in ('','-wal','-shm'):
            pathlib.Path(str(destino)+suffix).unlink(missing_ok=True)
        raise
    conn.close()
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('backup_json');p.add_argument('banco_sqlite');a=p.parse_args();importar(a.backup_json,a.banco_sqlite)
