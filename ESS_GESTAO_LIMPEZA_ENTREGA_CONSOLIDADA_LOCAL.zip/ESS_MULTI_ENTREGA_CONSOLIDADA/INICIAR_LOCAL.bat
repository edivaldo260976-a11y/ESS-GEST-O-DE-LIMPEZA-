@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (py -3 servidor_etapa6.py --banco ess_laboratorio.sqlite) else (python servidor_etapa6.py --banco ess_laboratorio.sqlite)
pause
