import hashlib,json,pathlib,sqlite3,sys
root=pathlib.Path(__file__).resolve().parent
backup=root/'BACKUP_ORIGINAL_NAO_ALTERAR.json'; db=root/'ess_laboratorio.sqlite'
doc=json.loads(backup.read_text(encoding='utf-8-sig'))
with sqlite3.connect(f'file:{db.as_posix()}?mode=ro',uri=True) as c:
    integrity=c.execute('PRAGMA integrity_check').fetchone()[0]
    original=dict(c.execute('SELECT chave,valor FROM armazenamento_original'))
    clients=c.execute('SELECT count(*) FROM clientes_snapshot').fetchone()[0]
    edits=c.execute('SELECT count(*) FROM dados_multi').fetchone()[0]
    users=c.execute('SELECT count(*) FROM usuarios_multi').fetchone()[0]
    stored_hash=c.execute('SELECT sha256_original FROM backup_info WHERE id=1').fetchone()[0]
print('Integridade SQLite:',integrity)
print('Chaves preservadas:',len(original),'| igualdade literal:',original==doc['localStorage'])
print('Clientes snapshot:',clients,'| declarados no backup:',doc.get('totalClientes'))
print('Edições de laboratório:',edits,'| usuários cadastrados:',users)
print('SHA256 backup:',hashlib.sha256(backup.read_bytes()).hexdigest())
print('SHA256 registrado na importação:',stored_hash)
assert integrity=='ok' and original==doc['localStorage'] and stored_hash==hashlib.sha256(backup.read_bytes()).hexdigest()
print('VALIDAÇÃO APROVADA')
