"""Laboratório local de autenticação, autorização e gravação separada da base original."""
import argparse, base64, hashlib, hmac, json, pathlib, secrets, sqlite3, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, unquote, parse_qs
from http.cookies import SimpleCookie
ROOT=pathlib.Path(__file__).resolve().parent
LOCK=threading.RLock()
def digest(password,salt):return hashlib.pbkdf2_hmac('sha256',password.encode(),salt,310000)
def setup(db):
 with sqlite3.connect(db) as c:
  c.execute('PRAGMA journal_mode=WAL')
  c.executescript('''CREATE TABLE IF NOT EXISTS usuarios_multi (usuario TEXT PRIMARY KEY, salt BLOB NOT NULL, hash BLOB NOT NULL, papel TEXT NOT NULL CHECK(papel IN ('admin','supervisor')), ativo INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS sessoes_multi (token_hash TEXT PRIMARY KEY, usuario TEXT NOT NULL REFERENCES usuarios_multi(usuario), expira INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS dados_multi (chave TEXT PRIMARY KEY, valor TEXT NOT NULL, revisao INTEGER NOT NULL DEFAULT 1, alterado_por TEXT NOT NULL, alterado_em INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS auditoria_multi (id INTEGER PRIMARY KEY AUTOINCREMENT, usuario TEXT NOT NULL, acao TEXT NOT NULL, chave TEXT, instante INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS permissoes_multi (usuario TEXT NOT NULL REFERENCES usuarios_multi(usuario), cliente TEXT NOT NULL REFERENCES clientes_snapshot(chave_origem), modulo TEXT NOT NULL CHECK(modulo IN ('locais','funcionarios')), permitido INTEGER NOT NULL CHECK(permitido IN (0,1)), PRIMARY KEY(usuario,cliente,modulo));''')
def connect(db):
 c=sqlite3.connect(db,timeout=15);c.execute('PRAGMA foreign_keys=ON');return c
def add_admin(db,user,password):
 if len(password)<12:raise ValueError('Senha deve ter ao menos 12 caracteres')
 salt=secrets.token_bytes(16)
 with connect(db) as c:
  if c.execute('SELECT count(*) FROM usuarios_multi').fetchone()[0]:raise ValueError('Já existem usuários; bootstrap bloqueado')
  c.execute('INSERT INTO usuarios_multi(usuario,salt,hash,papel) VALUES (?,?,?,?)',(user,salt,digest(password,salt),'admin'))
def handler(db):
 class H(BaseHTTPRequestHandler):
  def out(self,status,data):
   b=json.dumps(data,ensure_ascii=False).encode();self.send_response(status)
   for k,v in [('Content-Type','application/json; charset=utf-8'),('Cache-Control','no-store'),('X-Content-Type-Options','nosniff'),('Content-Length',str(len(b)))]:self.send_header(k,v)
   self.end_headers();self.wfile.write(b)
  def body(self):
   try:
    n=int(self.headers.get('Content-Length','0'))
    if n<1 or n>5_000_000:raise ValueError()
    v=json.loads(self.rfile.read(n));assert isinstance(v,dict);return v
   except (ValueError,AssertionError,json.JSONDecodeError):return None
  def who(self,c):
   token=self.headers.get('Authorization','')
   if not token.startswith('Bearer '):return None
   return c.execute('SELECT u.usuario,u.papel FROM sessoes_multi s JOIN usuarios_multi u ON s.usuario=u.usuario WHERE s.token_hash=? AND s.expira>? AND u.ativo=1',(hashlib.sha256(token[7:].encode()).hexdigest(),int(time.time()))).fetchone()
  def do_POST(self):
   path=urlparse(self.path).path;v=self.body()
   if v is None:return self.out(400,{'erro':'JSON inválido ou tamanho não permitido'})
   with LOCK,connect(db) as c:
    if path=='/api/login':
     name=v.get('usuario');pw=v.get('senha');row=c.execute('SELECT salt,hash FROM usuarios_multi WHERE usuario=? AND ativo=1',(name,)).fetchone() if isinstance(name,str) else None
     if not row or not isinstance(pw,str) or not hmac.compare_digest(digest(pw,row[0]),row[1]):return self.out(401,{'erro':'Credenciais inválidas'})
     token=secrets.token_urlsafe(40);c.execute('INSERT INTO sessoes_multi VALUES (?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),name,int(time.time())+8*3600));return self.out(200,{'token':token,'usuario':name,'papel':c.execute('SELECT papel FROM usuarios_multi WHERE usuario=?',(name,)).fetchone()[0],'expira_em_segundos':28800})
    who=self.who(c)
    if not who:return self.out(401,{'erro':'Autenticação necessária'})
    user,role=who
    if path=='/api/usuarios':
     if role!='admin':return self.out(403,{'erro':'Somente administrador'})
     name=v.get('usuario');pw=v.get('senha');r=v.get('papel')
     if not isinstance(name,str) or not (1<=len(name)<=64) or not isinstance(pw,str) or len(pw)<12 or r not in ('admin','supervisor'):return self.out(400,{'erro':'Usuário, senha (12+ caracteres) ou papel inválido'})
     salt=secrets.token_bytes(16)
     try:c.execute('INSERT INTO usuarios_multi(usuario,salt,hash,papel) VALUES (?,?,?,?)',(name,salt,digest(pw,salt),r))
     except sqlite3.IntegrityError:return self.out(409,{'erro':'Usuário existente'})
     c.execute('INSERT INTO auditoria_multi(usuario,acao,chave,instante) VALUES (?,?,?,?)',(user,'CRIAR_USUARIO',name,int(time.time())))
     return self.out(201,{'usuario':name,'papel':r})
    if path=='/api/permissoes':
     if role!='admin':return self.out(403,{'erro':'Somente administrador'})
     target=v.get('usuario');client=v.get('cliente');mod=v.get('modulo');allow=v.get('permitir')
     if not isinstance(target,str) or not isinstance(client,str) or mod not in ('locais','funcionarios') or type(allow)!=bool:return self.out(400,{'erro':'Permissão inválida'})
     if not c.execute('SELECT 1 FROM usuarios_multi WHERE usuario=? AND papel=?',(target,'supervisor')).fetchone():return self.out(404,{'erro':'Supervisor não encontrado'})
     if not c.execute('SELECT 1 FROM clientes_snapshot WHERE chave_origem=?',(client,)).fetchone():return self.out(404,{'erro':'Cliente não encontrado'})
     c.execute('INSERT INTO permissoes_multi VALUES (?,?,?,?) ON CONFLICT(usuario,cliente,modulo) DO UPDATE SET permitido=excluded.permitido',(target,client,mod,int(allow)))
     c.execute('INSERT INTO auditoria_multi(usuario,acao,chave,instante) VALUES (?,?,?,?)',(user,'PERMISSAO_LEITURA',target+'|'+client+'|'+mod+'|'+str(int(allow)),int(time.time())))
     return self.out(200,{'ok':True})
    if path=='/api/editar-registro':
     # Etapa 5: edição de uma linha somente, com revisão otimista do snapshot.
     # Nunca grava na tabela armazenamento_original nem substitui outros módulos.
     if role!='admin':return self.out(403,{'erro':'Edição de teste exclusiva do administrador'})
     key=v.get('cliente');mod=v.get('modulo');idx=v.get('indice');item=v.get('registro');rev=v.get('revisao_esperada')
     if not isinstance(key,str) or mod not in ('locais','funcionarios') or type(idx)!=int or idx<0 or not isinstance(item,(dict,list)) or (rev is not None and (type(rev)!=int or rev<1)):
      return self.out(400,{'erro':'Parâmetros inválidos'})
     if not c.execute('SELECT 1 FROM clientes_snapshot WHERE chave_origem=?',(key,)).fetchone():return self.out(404,{'erro':'Cliente inexistente'})
     existing=c.execute('SELECT valor,revisao FROM dados_multi WHERE chave=?',(key,)).fetchone()
     if existing:
      if existing[1]!=rev:return self.out(409,{'erro':'Dados alterados em outra sessão. Consulte novamente antes de editar.','revisao_atual':existing[1]})
      current=json.loads(existing[0]);newrev=existing[1]+1
     else:
      if rev is not None:return self.out(409,{'erro':'Revisão desatualizada; consulte novamente'})
      original=c.execute('SELECT valor FROM armazenamento_original WHERE chave=?',(key,)).fetchone()
      if not original:return self.out(404,{'erro':'Cliente sem dados originais'})
      current=json.loads(original[0]);newrev=1
     records=current.get(mod)
     if not isinstance(records,list) or idx>=len(records) or not isinstance(records[idx],(dict,list)):return self.out(422,{'erro':'Registro inexistente ou incompatível'})
     # Edição conservadora: mesmas chaves e tipos; evita apagar campos inadvertidamente.
     before=records[idx]
     if type(item) is not type(before) or (isinstance(before,dict) and (set(item)!=set(before) or any(type(item[k]) is not type(before[k]) for k in before))) or (isinstance(before,list) and (len(item)!=len(before) or any(type(a) is not type(b) for a,b in zip(item,before)))):return self.out(422,{'erro':'Preserve todos os campos e seus tipos. Nenhuma alteração foi gravada.'})
     records[idx]=item
     raw=json.dumps(current,ensure_ascii=False,separators=(',',':'))
     if len(raw.encode())>4_000_000:return self.out(413,{'erro':'Registro muito grande; nenhuma alteração gravada'})
     c.execute('INSERT INTO dados_multi(chave,valor,revisao,alterado_por,alterado_em) VALUES (?,?,?,?,?) ON CONFLICT(chave) DO UPDATE SET valor=excluded.valor,revisao=excluded.revisao,alterado_por=excluded.alterado_por,alterado_em=excluded.alterado_em',(key,raw,newrev,user,int(time.time())))
     c.execute('INSERT INTO auditoria_multi(usuario,acao,chave,instante) VALUES (?,?,?,?)',(user,'EDITAR_'+mod.upper(),key+'|'+str(idx),int(time.time())))
     return self.out(200,{'ok':True,'revisao':newrev,'indice':idx})
    if path=='/api/dados':
     if role!='admin':return self.out(403,{'erro':'Gravação liberada somente ao administrador nesta etapa de teste'})
     key=v.get('chave');value=v.get('dados');rev=v.get('revisao_esperada')
     if not isinstance(key,str) or not key.startswith('gl_cliente_v22_') or len(key)>300 or not isinstance(value,dict) or (rev is not None and (type(rev)!=int or rev<1)):return self.out(400,{'erro':'Chave, dados ou revisão inválidos'})
     raw=json.dumps(value,ensure_ascii=False,separators=(',',':'))
     if len(raw.encode())>4_000_000:return self.out(413,{'erro':'Registro muito grande'})
     old=c.execute('SELECT revisao FROM dados_multi WHERE chave=?',(key,)).fetchone()
     if old and old[0]!=rev:return self.out(409,{'erro':'Conflito de revisão','revisao_atual':old[0]})
     if not old and rev is not None:return self.out(409,{'erro':'Primeira gravação exige revisão nula'})
     new=(old[0]+1 if old else 1)
     c.execute('INSERT INTO dados_multi(chave,valor,revisao,alterado_por,alterado_em) VALUES (?,?,?,?,?) ON CONFLICT(chave) DO UPDATE SET valor=excluded.valor,revisao=excluded.revisao,alterado_por=excluded.alterado_por,alterado_em=excluded.alterado_em',(key,raw,new,user,int(time.time())))
     c.execute('INSERT INTO auditoria_multi(usuario,acao,chave,instante) VALUES (?,?,?,?)',(user,'GRAVAR_SNAPSHOT',key,int(time.time())))
     return self.out(200,{'chave':key,'revisao':new})
    return self.out(404,{'erro':'Rota inexistente'})
  def do_GET(self):
   parsed=urlparse(self.path);path=parsed.path
   if path in ('/','/painel.html'):
    page=(ROOT/'painel.html').read_bytes();self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'self'; object-src 'none'; base-uri 'none'");self.send_header('Content-Length',str(len(page)));self.end_headers();self.wfile.write(page);return
   with connect(db) as c:
    who=self.who(c)
    if not who:return self.out(401,{'erro':'Autenticação necessária'})
    if path=='/api/saude':return self.out(200,{'modo':'laboratorio local','usuario':who[0],'papel':who[1]})
    if path=='/api/modulo':
     qs=parse_qs(parsed.query);client=qs.get('cliente',[''])[0];mod=qs.get('modulo',[''])[0]
     if mod not in ('locais','funcionarios'):return self.out(400,{'erro':'Módulo inválido'})
     if who[1]!='admin' and not c.execute('SELECT 1 FROM permissoes_multi WHERE usuario=? AND cliente=? AND modulo=? AND permitido=1',(who[0],client,mod)).fetchone():return self.out(403,{'erro':'Sem permissão para este cliente/módulo'})
     row=c.execute('SELECT valor FROM dados_multi WHERE chave=?',(client,)).fetchone();source='laboratorio' if row else 'backup imutável'
     if not row:row=c.execute('SELECT valor FROM armazenamento_original WHERE chave=? AND chave LIKE ?', (client,'gl_cliente_v22_%')).fetchone()
     if not row:return self.out(404,{'erro':'Cliente inexistente'})
     val=json.loads(row[0]);items=val.get(mod,[])
     if not isinstance(items,list):return self.out(422,{'erro':'Dados do módulo não são uma lista'})
     return self.out(200,{'cliente':client,'modulo':mod,'origem':source,'revisao':c.execute('SELECT revisao FROM dados_multi WHERE chave=?',(client,)).fetchone()[0] if source=='laboratorio' else None,'registros':items})
    if path=='/api/clientes':
     rows=c.execute("SELECT chave_origem,nome_codificado FROM clientes_snapshot WHERE ?='admin' OR chave_origem IN (SELECT cliente FROM permissoes_multi WHERE usuario=? AND permitido=1) ORDER BY chave_origem",(who[1],who[0])).fetchall();return self.out(200,{'clientes':[{'chave':k,'nome':unquote(n)} for k,n in rows]})
    if path.startswith('/api/cliente/'):
     key=unquote(path[len('/api/cliente/'):]);
     if who[1]!='admin':return self.out(403,{'erro':'Consulta integral restrita ao administrador'})
     row=c.execute('SELECT valor,revisao FROM dados_multi WHERE chave=?',(key,)).fetchone()
     if row:return self.out(200,{'chave':key,'dados':json.loads(row[0]),'revisao':row[1],'origem':'laboratorio'})
     row=c.execute('SELECT valor FROM armazenamento_original WHERE chave=? AND chave LIKE ?', (key,'gl_cliente_v22_%')).fetchone()
     if row:return self.out(200,{'chave':key,'dados':json.loads(row[0]),'revisao':None,'origem':'backup imutavel'})
     return self.out(404,{'erro':'Cliente inexistente'})
    return self.out(404,{'erro':'Rota inexistente'})
  def do_PUT(self):return self.out(405,{'erro':'Método não permitido'})
  do_PATCH=do_PUT;do_DELETE=do_PUT
  def log_message(self,*args):pass
 return H
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--banco',default=str(ROOT/'ess_laboratorio_etapa3.sqlite'));p.add_argument('--porta',type=int,default=8765);p.add_argument('--criar-admin',nargs=2,metavar=('USUARIO','SENHA'));a=p.parse_args()
 if not pathlib.Path(a.banco).is_file():p.error('Banco não encontrado')
 setup(a.banco)
 if a.criar_admin:
  add_admin(a.banco,*a.criar_admin);print('Administrador criado.');raise SystemExit(0)
 print('Painel local em http://127.0.0.1:'+str(a.porta)+'/ (não publicar na internet)',flush=True)
 ThreadingHTTPServer(('127.0.0.1',a.porta),handler(a.banco)).serve_forever()
