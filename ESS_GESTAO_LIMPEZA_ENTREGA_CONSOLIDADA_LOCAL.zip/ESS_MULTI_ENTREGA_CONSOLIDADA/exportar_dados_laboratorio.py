"""Exporta uma cópia JSON do estado de laboratório, sem modificar o backup original."""
import datetime,json,pathlib,sqlite3,sys
root=pathlib.Path(__file__).resolve().parent
out=root/('EXPORTACAO_LABORATORIO_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'.json')
with sqlite3.connect(f'file:{(root/"ess_laboratorio.sqlite").as_posix()}?mode=ro',uri=True) as c:
    base=dict(c.execute('SELECT chave,valor FROM armazenamento_original'))
    changes=dict(c.execute('SELECT chave,valor FROM dados_multi'))
    revisions={k:r for k,r in c.execute('SELECT chave,revisao FROM dados_multi')}
for k,v in changes.items():base[k]=v
out.write_text(json.dumps({'tipo':'EXPORTACAO_LABORATORIO_NAO_IMPORTAR_NA_V426_SEM_VALIDACAO','geradoEm':datetime.datetime.now(datetime.timezone.utc).isoformat(),'localStorage':base,'revisoes':revisions},ensure_ascii=False,indent=2),encoding='utf-8')
print('Cópia exportada:',out.name,'| chaves:',len(base),'| clientes editados:',len(changes))
